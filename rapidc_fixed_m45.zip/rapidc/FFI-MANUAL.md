# rapidc FFI Kılavuzu

Bu belge, Rapid! dilinden C kütüphanelerine erişmenin üç yolunu —
`extern fn`, `keyword`, ve C shim deseni — baştan sona, "ne işe yarar /
nasıl tanımlanır / nasıl kullanılır / neden böyle tasarlandı" sırasıyla
anlatır. Derleyici kaynağına (`parser.y`, `semantic.c`, `codegen.c`) hiç
dokunmadan eklendiler; hepsi ya doğrudan bir grammar kuralı (`extern fn`)
ya da o kuralın üstüne kurulmuş saf metinsel bir kısayoldur (`keyword`).

---

## İçindekiler

1. [FFI nedir, neden var](#1-ffi-nedir-neden-var)
2. [Katman 1: `extern fn` — temel taş](#2-katman-1-extern-fn--temel-taş)
3. [`link "..."` — kütüphane bağlama](#3-link---kütüphane-bağlama)
4. [Katman 2: `keyword` — kısayol](#4-katman-2-keyword--kısayol)
5. [`keyword` rename: isim ≠ C sembolü](#5-keyword-rename-isim--c-sembolü)
6. [Katman 3: C shim — dilin ifade edemediği imzalar](#6-katman-3-c-shim--dilin-ifade-edemediği-imzalar)
7. [Derleme: `-obj` ve `-l` bayrakları](#7-derleme--obj-ve--l-bayrakları)
8. [Üç katmanı ne zaman hangisini seçmeli](#8-üç-katmanı-ne-zaman-hangisini-seçmeli)
9. [Sınırlar ve bilinen tuzaklar](#9-sınırlar-ve-bilinen-tuzaklar)
10. [Uçtan uca örnek: libm](#10-uçtan-uca-örnek-libm)
11. [Uçtan uca örnek: shim'li bir C kütüphanesi](#11-uçtan-uca-örnek-shimli-bir-c-kütüphanesi)

---

## 1) FFI nedir, neden var

**FFI** (Foreign Function Interface) — Rapid! kodundan, Rapid! ile
yazılmamış (C ile derlenmiş) bir fonksiyonu çağırabilme yeteneği.

**Neden gerekli:** rapidc kendi başına küçük bir dil; dosya G/Ç'sinin
büyük kısmı, matematik fonksiyonları (`sqrt`, `sin`, `fabs`...), ağ
erişimi (libcurl), veritabanları (sqlite3) gibi şeyler zaten C
kütüphanelerinde onlarca yıldır yazılmış ve test edilmiş durumda.
Bunları rapidc'de sıfırdan yeniden yazmak yerine, var olan C ABI'sine
(Application Binary Interface — fonksiyonların bellekte nasıl
çağrıldığına dair sözleşme) doğrudan bağlanmak çok daha ucuz.

**Nasıl mümkün oluyor:** rapidc, kodu QBE ara-diline, oradan da native
x86-64 assembly'ye çeviriyor ve son adımda sistem `cc`'siyle linkliyor
(bkz. `README.md`'deki pipeline: `.rapid → AST → QBE IL → qbe → cc →
ELF64`). C ile derlenmiş bir `.o`/`.so` da aynı `cc` link adımına dahil
olabildiği için, rapidc'nin yapması gereken tek şey: derleme zamanında
"bu isimdeki sembolü dışarıda ara" demek. `extern fn` tam olarak budur.

---

## 2) Katman 1: `extern fn` — temel taş

### Ne yapar

`extern fn`, rapidc'ye "bu fonksiyon benim kaynağımda tanımlı değil,
C tarafında bir yerde var, imzası şu" der. Gövde yazmazsın (`{ ... }`
yok), çünkü kodu zaten C tarafında.

### Nasıl tanımlanır

```
extern fn <isim>(<param>: <tip>, ...): <dönüş_tipi>;
```

Örnek:

```
extern fn sqrt(x: double): double;
extern fn strlen(s: string): int;
extern fn printf(fmt: string, ...): int;   // varargs
extern fn exit(code: int): void;
```

Kurallar (`parser.y`'deki `extern_decl` kuralından):

- Gövde yok, `;` ile biter (normal `fn`'in `{ ... }` bloğu yerine).
- Dönüş tipi **her zaman açık yazılır** — normal `fn`'de "yazmazsan void"
  kısayolu vardır, `extern fn`'de yoktur; void dönüş bile `: void` diye
  yazılmalı. Neden: dışarıdan gelen bir imza için "sessizce void varsay"
  demek, gerçek C imzasıyla sessizce uyuşmayan bir derleme üretebilir —
  açık yazım hata payını azaltır.
- Varargs için sondaki parametre `...` olabilir (`printf` örneğindeki
  gibi) — ama bu yalnızca `extern fn`'e özeldir, normal `fn`/`efn`
  varargs alamaz (`parser.y`'de ayrı bir `extern_param_list` grammar
  dalı var, düz `param_list`'ten bağımsız, tam bu yüzden).

### Nasıl kullanılır

Tanımladıktan sonra sıradan bir fonksiyon gibi çağrılır — çağıran taraf
için hiçbir fark yoktur:

```
extern fn sqrt(x: double): double;
link "m";

fn main() {
    io::out(sqrt(2.0));   // 1.41421
}
```

### Neden böyle tasarlandı

- **Codegen'e yeni bir case gerektirmiyor.** `extern fn`, semantic.c'nin
  imza kayıt tablosuna (Pass 1) normal bir fonksiyon gibi giriyor,
  codegen de onu `$<isim>` şeklinde çağırıyor — tıpkı Rapid!'in kendi
  yazdığın bir `fn`'i gibi. Fark yalnızca: bu isim için rapidc kendi
  gövdesini üretmiyor, dışarıdan (C tarafından) geleceğini varsayıp
  sembolü **tanımsız (undefined)** bırakıyor; linkleme aşamasında `cc`
  bu sembolü libc/verilen kütüphanede bulup bağlıyor.
- **İmza kontrolü yapılır ama gövde doğrulanmaz.** rapidc, `sqrt(2.0)`
  çağrısında argüman tipinin `double` olduğunu kontrol eder (semantic.c),
  ama `sqrt`'in gerçekten öyle davrandığını bilemez — bu tamamen sana,
  yani doğru imza yazmana bağlıdır. Yanlış imza yazarsan (örn. `int`
  yerine `double` beklerken `int` yazarsan) derleme geçer ama çalışma
  zamanında bozuk veri okunur/yazılır — bu C FFI'nin evrensel riskidir,
  rapidc'ye özel değil.
- **First-class değer olarak da kullanılabilir (M28).** Bir `extern fn`
  adı, çağrılmadan bir değişkene atanabilir ve dolaylı çağrılabilir
  (`var f = printf; f("merhaba");`), aynı normal `fn`ler gibi — imza
  kayıt tablosuna aynı yoldan girdiği için bu bedavaya geliyor.

---

## 3) `link "..."` — kütüphane bağlama

### Ne yapar

`sqrt` gibi bir sembol `libc`'de değil `libm`'de yaşıyorsa, linker'a
"libm'i de bağla" demen gerekir — tıpkı `cc prog.c -lm` yazman gibi.
`link "m";` direktifi tam bunu yapar.

### Nasıl tanımlanır / kullanılır

```
link "m";     // -lm olarak linklenir
```

Dosyanın herhangi bir yerine, herhangi bir sırada yazılabilir
(deklarasyon niteliğinde, kod akışını etkilemez). Birden fazla
`link` direktifi olabilir, her biri ayrı bir `-l<isim>` bayrağına
dönüşür.

### Neden böyle tasarlandı

`link` bir AST düğümü bile üretmiyor — parser onu görür görmez
`g_program.link_libs` listesine ekliyor (`main.c`'nin son `cc` komut
satırını kurduğu yerde bu liste `-l<isim> -l<isim> ...` şeklinde
sıraya diziliyor). Yani `link`, codegen'in hiç haberi olmayan, saf
"derleme talimatı" katmanında yaşıyor — build sistemine (`Makefile`
ya da `cc` komut satırına) elle `-lm` eklemek zorunda kalmaman için.

---

## 4) Katman 2: `keyword` — kısayol

### Ne yapar

`extern fn` + (gerekiyorsa) `link` yazmak, sık kullanılan bir C
fonksiyonu için tekrar tekrar aynı 2 satırı yazmak demek. `keyword`,
bunları **tek satıra** indiren, saf metinsel bir kısayoldur — hiçbir
yeni derleyici davranışı eklemez, sadece senin yazmak zorunda olduğun
satır sayısını azaltır.

### Nasıl tanımlanır

```
keyword <isim>(<param>: <tip>, ...): <dönüş_tipi> => extern "<C_sembolü>" [from "<kütüphane>"];
```

Örnek:

```
keyword sqrt(x: double): double => extern "sqrt" from "m";
keyword strlen(s: string): int  => extern "strlen";
keyword printf(fmt: string, ...): int => extern "printf";
keyword exit(code: int): void => extern "exit";
```

### Nasıl kullanılır

Tanımlandıktan sonra, `isim`i sanki Rapid!'in kendi yerleşik bir
komutuymuş gibi çağırırsın:

```
fn main() {
    io::out(sqrt(2.0));         // 1.41421
    io::out(strlen("merhaba")); // 7
    printf("sayi: %ld\n", 42);
    exit(0);
}
```

`from "kütüphane"` kısmı opsiyoneldir — vermezsen yalnızca zaten libc'de
örtük linklenen semboller (`strlen`, `printf`, `exit` gibi) hedeflenebilir.

### Neden böyle tasarlandı: "saf metin makrosu" prensibi

Bu, `keyword`'ün en önemli tasarım kararı: **derleyici kaynağına
(lexer/parser/semantic/codegen) hiç dokunulmuyor.** `keyword` bildirimi,
modül birleştirme adımının sonunda, kaynak lexer'a verilmeden hemen önce
çalışan bir metin-genişletme geçişinde (`module.c: expand_keyword_decls`)
tanınıyor ve **kelimesi kelimesine** zaten var olan `extern fn` + `link`
sözdizimine genişletiliyor:

```
keyword sqrt(x: double): double => extern "sqrt" from "m";
```

lexer hiç görmeden önce şuna dönüşüyor:

```
link "m";
extern fn sqrt(x: double): double;
```

Bu yüzden `keyword`, yeni bir token, yeni bir AST düğümü, yeni bir
semantic-check dalı ya da yeni bir codegen case'i **gerektirmiyor** —
çağrı sitesindeki tip kontrolü, `$<isim>` codegen'i ve `-l<kütüphane>`
link bayrağı tamamen mevcut `extern fn`/`link` makinesinden miras
alınıyor. `keyword` "yeni bir özellik" değil, "var olan iki özelliğin
otomatik birleşimi"dir.

---

## 5) `keyword` rename: isim ≠ C sembolü

### Ne zaman gerekir

Bazen C tarafındaki gerçek sembol ismini Rapid! tarafında olduğu gibi
kullanmak istemezsin — örneğin kendi yazdığın bir shim fonksiyonu
`rapidc_http_get` diye adlandırılmış ama Rapid! kodunda sadece
`http_get(...)` demek istiyorsun. `keyword`'de isim (`ad`) ile C sembolü
(`csembol`) farklı olabilir:

```
keyword http_get(url: string, out_status: int*): string
    => extern "rapidc_http_get";
```

### Nasıl çalışır

İsim ile C sembolü eşleşmediğinde, `expand_keyword_decls` **iki parça**
üretir:

1. Gerçek C sembolü altında, çakışmayı önlemek için isim-uzaylı
   (namespaced) gizli bir `extern fn`:
   ```
   extern fn __kw_ffi_rapidc_http_get(url: string, out_status: int*): string;
   ```
2. Senin gördüğün genel isim altında, tüm parametreleri pozisyonel
   sırayla gizli extern'e ileten küçük bir `efn` **forwarding wrapper**:
   ```
   efn http_get(url: string, out_status: int*) => __kw_ffi_rapidc_http_get(url, out_status);
   ```

Yani `http_get(...)` çağırdığında aslında iki fonksiyon atlıyorsun:
`http_get` (efn wrapper) → `__kw_ffi_rapidc_http_get` (gerçek C sembolü).

### Neden böyle tasarlandı

`extern fn`'in codegen'i her zaman bildirilen ismi düz `$<isim>`
sembolüne çağırıyor (M27 tasarımı) — `ad` ile gerçek C sembolü arasına
bir yeniden-adlandırma/alias katmanı **doğrudan codegen'e eklemek**
gerekirdi, bu da `keyword`'ün "derleyici koduna dokunmadan" hedefiyle
çelişirdi. Bunun yerine, zaten var olan iki mekanizma (`extern fn` +
`efn`) birleştirilerek aynı sonuca metinsel olarak ulaşılıyor: `efn`
zaten "kısa bir ifadeyi çağırıp sonucunu döndüren fonksiyon" demek
biliyor, gerçek işi ona devrediyoruz.

### Bilinen sınır: varargs rename edilemez

```
keyword my_printf(fmt: string, ...): int => extern "printf";   // HATA
```

Bu, derleme zamanında açık bir hatayla reddedilir: *"renaming a
variadic FFI symbol is not supported"*. Neden: `efn` wrapper'ı
parametreleri **isimle** ileri taşıyor (`http_get(url, out_status) =>
__kw_ffi_...(url, out_status)`), ama `...` bir isim değil — kaç tane
ekstra argüman geleceği derleme zamanında bilinmiyor, `efn` bunu
ileremiyor. İsim eşleşiyorsa (`keyword printf(...) => extern "printf";`)
sorun yok, çünkü o durumda hiç `efn` wrapper'ı üretilmiyor, direkt
`extern fn` kullanılıyor (bkz. Bölüm 4).

---

## 6) Katman 3: C shim — dilin ifade edemediği imzalar

### Ne zaman gerekir

`extern fn` yalnızca rapidc'nin zaten anladığı tipleri (`int`, `double`,
`string`, `T*` — tek seviye pointer, vb.) ifade edebilir. Bazı C
fonksiyonları bunun dışına çıkar:

- **Pointer'a pointer** (`T**`) — sqlite3'ün `sqlite3_open(const char*,
  sqlite3**)` imzası gibi; rapidc'nin pointer tipi tek seviye (`T*`),
  `T**` bir gramer hatası.
- **Union-tipli varargs** — libcurl'ün `curl_easy_setopt` gibi
  fonksiyonları, aynı çağrı şeklinde hem int, hem string, hem
  fonksiyon-pointer'ı kabul eder; bu tek bir `extern fn` imzasıyla
  ifade edilemez.
- **C fonksiyon pointer'ı callback** (örn. libcurl'ün
  `WRITEFUNCTION`'ı) — rapidc'nin `fn` tipi bir C fonksiyon pointer'ına
  doğrudan çevrilebilecek bir ABI garantisi vermiyor.

### Nasıl tanımlanır

Çözüm: aradaki C fonksiyonunu **düzleştiren** ince bir C dosyası (shim)
yazarsın. Shim, karmaşık gerçek API'yi çağırıp, rapidc'nin anlayabildiği
düz bir imzayla (`extern fn`'in ifade edebildiği: skaler tipler, tek
seviye pointer, string) sonucu geri verir.

Örnek (`ffi/sqlite3_shim.c`'den, basitleştirilmiş):

```c
// gerçek C imzası: int sqlite3_open(const char *filename, sqlite3 **ppDb);
// T** ifade edilemiyor -> handle'ı bir "long" dönüş değeri yap
long rapidc_sqlite3_open(const char *filename) {
    sqlite3 *db;
    int rc = sqlite3_open(filename, &db);
    g_last_rc = rc;              // hata kodu ayrı bir global'de
    return (long)db;             // handle'ı opak bir sayı gibi ilet
}

int rapidc_sqlite3_open_rc(void) {
    return g_last_rc;
}
```

Rapid! tarafında bu ince katman normal bir `extern fn` ile bildirilir:

```
extern fn rapidc_sqlite3_open(filename: string): int;
extern fn rapidc_sqlite3_open_rc(): int;
```

Handle (`sqlite3*`), Rapid! tarafında hiç alanlarına erişilmeyen, sadece
diğer `sqlite3_*` çağrılarına geri verilen **opak bir `int`** olarak
taşınır — Rapid! onun bir pointer olduğunu bile bilmek zorunda değil.

### Neden böyle tasarlandı

Bu desen rapidc'ye özel değil — gerçek dünyadaki hemen her dilde
(Rust'ın `bindgen`'i, Go'nun `cgo`'su, Python'ın C uzantıları) aynı
prensip uygulanır: bir C ABI'sinin hedef dile **doğrudan çevrilemeyen**
kısımları (pointer'a pointer, struct by-value, union, variadic'in
kendisi, fonksiyon pointer callback'leri) ince bir shim katmanıyla
"düzleştirilip" asıl dile öyle sunulur. rapidc'nin kendisi `.c` dosyası
derlemediği için (bkz. Bölüm 7), bu shim'i **sen önceden `cc` ile
derleyip** son link adımına elle eklersin.

`keyword` ile shim genellikle birlikte kullanılır — shim düz bir C
fonksiyonu ürettiği için, `keyword`'ün rename özelliğiyle o düz
fonksiyonu istediğin kısa isimle Rapid!'e sunabilirsin (bkz.
Bölüm 11'deki `http_get` örneği).

---

## 7) Derleme: `-obj` ve `-l` bayrakları

### Ne yapar

rapidc kendi başına yalnızca `.rapid` dosyalarını derler — bir `.c`
dosyasını asla kendisi derlemez/linklemez. Shim kullanıyorsan, shim'i
**önce sen** `cc` ile `.o`'ya çevirip, rapidc'nin son link komutuna
**elle eklemen** gerekir.

### Nasıl kullanılır

```bash
# 1) Shim'i derle
cc -c ffi/sqlite3_shim.c -o ffi/sqlite3_shim.o

# 2) rapidc'ye linklerken şu .o'yu da ekle
rapidc examples/sqlite_demo.rapid -obj ffi/sqlite3_shim.o -o demo
```

- **`-obj <dosya.o>`** — verilen `.o` dosyasını, rapidc'nin kendi
  ürettiği asıl `.o`/assembly ile birlikte son `cc` komutuna ekler.
- **`-l<kütüphane>`** — `link "...";` kaynak direktifiyle tamamen aynı
  işi görür (`-l<isim>` bayrağı eklemek), ama komut satırından, kaynağa
  dokunmadan yapmak istediğinde.

### Neden böyle tasarlandı

rapidc'nin görev tanımı ".rapid'i C ABI'siyle uyumlu native koda çevirmek"
— genel amaçlı bir C derleyicisi/build sistemi olmak değil. `.c`
derlemeyi de üstlenmek, `cc`'nin zaten çok iyi yaptığı bir işi
tekrarlamak, ve `-I`/`-D`/optimizasyon bayrakları gibi koca bir C
derleme yapılandırma yüzeyini rapidc'ye taşımak demek olurdu. Bunun
yerine rapidc, kendi ürettiği kodu **var olan** bir `.o`'nun yanına
koyup `cc`'ye "ikisini birlikte linkle" demeyi tercih ediyor — Unix
felsefesindeki "her araç bir işi iyi yapsın" prensibine uygun.

---

## 8) Üç katmanı ne zaman hangisini seçmeli

| Durum | Kullan |
|---|---|
| Tek bir C fonksiyonunu bir kere çağıracaksın, kısayola gerek yok | `extern fn` + gerekirse `link` |
| Sık kullanacağın, imzası rapidc'nin doğrudan ifade edebildiği bir C fonksiyonu (skaler tipler, tek seviye pointer) | `keyword` (isim eşleşen) |
| Kendi yazdığın bir shim fonksiyonunu daha kısa/temiz bir isimle sunmak istiyorsun | `keyword` (rename'li) |
| C fonksiyonunun imzası rapidc'nin ifade edemediği bir şey içeriyor (`T**`, union varargs, callback) | Önce **C shim** yaz, sonra shim'i `extern fn` (gerekirse `keyword` ile) bildir |

Basit kural: **`extern fn` her zaman yeterli ve doğru** bir başlangıç
noktasıdır — `keyword` sadece "daha az yazmak" için var, zorunlu değil.
Şüphede kalırsan `extern fn` ile başla, işe yarıyorsa istersen sonra
`keyword`'e kısalt.

---

## 9) Sınırlar ve bilinen tuzaklar

- **`extern fn`, C tarafının imzasını doğrulamaz.** Yanlış tip yazarsan
  derleme geçer ama çalışma zamanında bozuk veri okunur/yazılır. Bu C
  FFI'nin evrensel doğası — rapidc'ye özel değil.
- **`keyword` varargs rename edemez** (bkz. Bölüm 5) — isim ile C sembolü
  aynıysa (`keyword printf(...) => extern "printf";`) sorun yok, farklıysa
  derleme zamanında net bir hatayla durur.
- **`keyword`, rename'li olduğunda hata mesajları sızdırır.** Bir link
  hatası aldığında (`undefined reference to __kw_ffi_...`), gördüğün
  sembol senin yazdığın isim değil, otomatik üretilen gizli isim
  olacaktır — bu normal, kafa karıştırıcı olabilir ama zararsız.
- **Aliaslı `use "...rapid" as alias;` artık `extern fn`/`keyword`
  isimlerini de doğru mangle ediyor** (`db::sqlite3_close` →
  `db__sqlite3_close`, hem tanım hem çağrı tarafında tutarlı) — modül
  sistemi bir ismi `fn`/`efn`/`extern fn`/`keyword` ayırt etmeden aynı
  üst-düzey isim uzayında topluyor (`scan_top_level`), bu yüzden
  `alias::name` her ikisi için de aynı şekilde çalışır. FFI
  binding'lerini alias'lı ya da alias'sız import edebilirsiniz.
- **`keyword`, dosyanın yalnızca üst düzey (top-level) satırlarını
  tanır** — bir string literal içinde geçen "keyword" kelimesi (örn.
  `io::out("keyword deneme");`) yanlışlıkla genişletilmez, tam satır
  taraması ve string-literal atlaması bunu garantiler.
- **Shim `.o`'ları rapidc'nin build sistemine dahil değil** — her
  derlemede shim'i elle güncel tutman/derlemen gerekir; rapidc bunu
  senin için izlemiyor (bkz. Bölüm 7).

---

## 10) Uçtan uca örnek: libm

```
// math_demo.rapid
extern fn sqrt(x: double): double;
extern fn fabs(x: double): double;
link "m";

fn main() {
    io::out(sqrt(2.0));    // 1.41421
    io::out(fabs(-5.5));   // 5.5
}
```

Derleme ve çalıştırma:

```bash
rapidc math_demo.rapid -o math_demo
./math_demo
```

Burada `-obj` gerekmez, çünkü `sqrt`/`fabs` doğrudan `extern fn` ile
ifade edilebiliyor — aradaki bir shim'e ihtiyaç yok, sadece `link "m";`
ile libm'e bağlanmak yeterli.

`keyword` ile aynısı, tek satır tanımlarla:

```
keyword sqrt(x: double): double => extern "sqrt" from "m";
keyword fabs(x: double): double => extern "fabs" from "m";

fn main() {
    io::out(sqrt(2.0));
    io::out(fabs(-5.5));
}
```

---

## 11) Uçtan uca örnek: shim'li bir C kütüphanesi

libcurl'ün `curl_easy_setopt` API'si (union-tipli varargs + fonksiyon
pointer callback) doğrudan `extern fn` ile ifade edilemiyor, bu yüzden
bir shim gerekiyor.

**Adım 1 — Shim yaz** (`net_shim.c`):

```c
#include <curl/curl.h>
#include <string.h>
#include <stdlib.h>

static size_t write_cb(void *data, size_t sz, size_t n, void *userp) {
    /* gövdeyi bir buffer'a biriktir, döndürülen byte sayısını ver */
    ...
}

char *rapidc_http_get(const char *url, long *out_status) {
    CURL *c = curl_easy_init();
    curl_easy_setopt(c, CURLOPT_URL, url);
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, write_cb);
    /* ... gövdeyi topla ... */
    curl_easy_perform(c);
    curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, out_status);
    curl_easy_cleanup(c);
    return strdup(body);   // Rapid! tarafına düz bir string döner
}

void rapidc_http_free(char *body) { free(body); }
```

**Adım 2 — Shim'i, `keyword` rename ile Rapid!'e tanıt** (`net.rapid`):

```
link "curl";

keyword http_get(url: string, out_status: int*): string
    => extern "rapidc_http_get";

keyword http_free(body: string): void
    => extern "rapidc_http_free";
```

**Adım 3 — Kullan:**

```
use "net.rapid";

fn main() {
    var status: int* = alloc(8);
    var body: string = http_get("http://example.com", status);
    io::out(*status);   // HTTP durum kodu, örn. 200
    io::out(body);      // yanıt gövdesi
    http_free(body);
    free(status);
}
```

**Adım 4 — Derle:**

```bash
cc -c net_shim.c -o net_shim.o
rapidc app.rapid -obj net_shim.o -o app
# link "curl"; kaynakta zaten var, -lcurl otomatik eklenir
```

Bu örnekte üç katmanın hepsi birlikte çalışıyor: C shim (karmaşık
libcurl API'sini düzleştiriyor) + `keyword` rename (shim'in çirkin
`rapidc_http_get` ismini temiz `http_get`'e çeviriyor) + `link`
(libcurl'ü bağlıyor). Kullanıcı tarafında (Adım 3) hiçbir C/FFI izi
görünmüyor — sanki `http_get` Rapid!'in kendi yerleşik bir fonksiyonuymuş
gibi çağrılıyor.
