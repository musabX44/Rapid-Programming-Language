#!/bin/bash
# Birlesik test kosucusu. Kullanim: ./run_tests.sh   (veya `make test`)
# Onkosul: `make` ile rapidc + runtime.o derlenmis, `qbe` PATH'te.
#
# Kesfedilen testler: m*tests/test_*.rapid ve examples/*.rapid
#  - Beklenen-hata testi: dosyada `// EXPECT-ERROR: <metin>` satiri(lari) varsa
#    derleme BASARISIZ olmali ve stderr her <metin>'i icermeli. Eski testler icin
#    acik bir eski-test listesi (FAIL_NAME_RE) de gecerli; bunlarda yalniz
#    "derleme basarisiz olmali" kontrol edilir. (Not: bazi eski testlerin adinda
#    `_error` gecse de aslinda derlenir; bu yuzden ad deseni degil liste kullanilir.)
#  - Normal test: derlenmeli. `.expected` varsa program calistirilip cikti
#    birebir karsilastirilir; yoksa sadece calisir (cokme/zaman asimi = hata).
#  - SKIP: dis bagimlilik isteyenler (libcurl/sqlite) -- asagidaki SKIP_RE.
# Ek olarak mevcut ozel kosucular (m38 enjeksiyon, m41 modul/std) calistirilir.
# Cikis kodu: herhangi bir FAIL varsa 1.

ROOT="$(cd "$(dirname "$0")" && pwd)"
RAPIDC="$ROOT/rapidc"
SKIP_RE='stdlib_net|sqlite_demo|kwlib|std_missing_use_error'  # son ikisi: -nostd gerekir, run_m41.sh kapsar
FAIL_NAME_RE='extern_redecl_error|cross_file_conflict_error|dup_extern_same_file_error|fixed_array_removed_error|overload_same_sig_error|_reject$|inject_link_directive|alias_builtin_len'

[ -x "$RAPIDC" ] || { echo "rapidc yok: once 'make' calistirin"; exit 2; }
command -v qbe >/dev/null || { echo "qbe PATH'te degil"; exit 2; }

W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
pass=0; fail=0; skip=0

report() { # durum ad [ayrinti]
  case "$1" in
    ok)   pass=$((pass+1)); [ -n "$VERBOSE" ] && echo "ok:   $2" ;;
    SKIP) skip=$((skip+1)); echo "SKIP: $2 ($3)" ;;
    FAIL) fail=$((fail+1)); echo "FAIL: $2 -- $3" ;;
  esac
}

for src in "$ROOT"/m*tests/test_*.rapid "$ROOT"/examples/*.rapid; do
  [ -e "$src" ] || continue
  n="${src#$ROOT/}"; b=$(basename "$src" .rapid)
  if [[ "$b" =~ $SKIP_RE ]]; then report SKIP "$n" "dis bagimlilik veya ozel kosucu kapsiyor"; continue; fi
  dir=$(dirname "$src")
  mapfile -t expects < <(grep -h '^// EXPECT-ERROR:' "$src" | sed 's|^// EXPECT-ERROR: *||')
  if [ ${#expects[@]} -gt 0 ] || [[ "$b" =~ $FAIL_NAME_RE ]]; then
    err=$(cd "$dir" && "$RAPIDC" "$(basename "$src")" -o "$W/a" 2>&1); rc=$?
    if [ $rc -eq 0 ]; then report FAIL "$n" "derleme hata vermeliydi"; continue; fi
    ok=1
    for e in "${expects[@]}"; do
      grep -qF -- "$e" <<<"$err" || { report FAIL "$n" "stderr'de beklenen metin yok: '$e'"; ok=0; break; }
    done
    [ $ok -eq 1 ] && report ok "$n"
    continue
  fi
  log=$(cd "$dir" && "$RAPIDC" "$(basename "$src")" -o "$W/a" 2>&1) || { report FAIL "$n" "derlenmedi: $(grep -v '^+' <<<"$log" | head -2 | tr '\n' ' ')"; continue; }
  out=$(timeout 10 "$W/a" </dev/null 2>/dev/null); rc=$?
  if [ $rc -ge 124 ]; then report FAIL "$n" "calisma hatasi (rc=$rc)"; continue; fi
  exp="${src%.rapid}.expected"
  if [ -f "$exp" ]; then
    if [ "$out" = "$(cat "$exp")" ]; then report ok "$n"; else report FAIL "$n" "cikti .expected ile farkli"; fi
  else
    report ok "$n"
  fi
done

echo "--- ozel kosucular"
for r in "$ROOT"/m38tests/run_inject_test.sh "$ROOT"/m41tests/run_m41.sh; do
  [ -x "$r" ] || [ -f "$r" ] || continue
  if out=$(bash "$r" 2>&1); then report ok "$(basename "$r")"; [ -n "$VERBOSE" ] && echo "$out"
  else report FAIL "$(basename "$r")" "$(grep -E '^FAIL' <<<"$out" | head -3 | tr '\n' ';')"; fi
done

echo "=== gecti: $pass   basarisiz: $fail   atlandi: $skip"
[ $fail -eq 0 ]
