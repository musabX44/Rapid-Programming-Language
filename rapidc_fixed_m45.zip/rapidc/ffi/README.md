# rapidc FFI kütüphaneleri

Bu klasör, `link "..."` + `extern fn` üzerine kurulu, kullanıcı alanında
yazılmış örnek bir FFI bağlantısı içerir: **`sqlite3.rapid`**, libsqlite3'e
bağlanan minimal bir binding.

## `sqlite3.rapid` nasıl kullanılır

```
use "../ffi/sqlite3.rapid";

fn main() {
    var handle: int = rapidc_sqlite3_open("veritabani.db");
    if (rapidc_sqlite3_open_rc() != 0) {
        io::out("acilamadi");
        return;
    }
    sqlite3_exec(handle, "CREATE TABLE IF NOT EXISTS kisi (id INTEGER PRIMARY KEY, ad TEXT);", 0, 0, 0);
    sqlite3_exec(handle, "INSERT INTO kisi (ad) VALUES ('Yasin');", 0, 0, 0);
    io::out(sqlite3_changes(handle));
    sqlite3_close(handle);
}
```

Derleme (M31'den itibaren tek komut yeterli):

```
rapidc examples/sqlite_demo.rapid -o demo
```

- `sqlite3.rapid` artık `shim "sqlite3_shim.c";` içeriyor, bu yüzden
  `sqlite3_shim.c` rapidc tarafından otomatik `cc -c` ile derlenip son
  link adımına eklenir — ayrı bir `cc -c ffi/sqlite3_shim.c -o
  ffi/sqlite3_shim.o` adımına gerek yok.
- Sisteminizde `libsqlite3` runtime kütüphanesi kurulu olmalı, ve linker'ın
  aradığı `libsqlite3.so` (versiyon numarasız) sembolik linki mevcut
  olmalı — bazı dağıtımlarda bu yalnızca `-dev` paketiyle gelir:
  `sudo ln -sf /usr/lib/x86_64-linux-gnu/libsqlite3.so.0 /usr/lib/x86_64-linux-gnu/libsqlite3.so`
  (veya `apt install libsqlite3-dev`).

## Neden bir C shim (`sqlite3_shim.c`) var

`sqlite3_open`'ın gerçek C imzası:

```c
int sqlite3_open(const char *filename, sqlite3 **ppDb);
```

`ppDb` bir **pointer'a pointer** (çıktı parametresi). rapidc'nin pointer
tipi yalnızca tek seviye (`T*`) destekliyor — `T**` bir gramer hatası.
Bu yüzden `sqlite3_open`'ı doğrudan `extern fn` ile bildiremiyoruz.

`sqlite3_shim.c`, gerçek `sqlite3_open`'ı çağırıp elde ettiği `sqlite3*`
handle'ı bir `long` **dönüş değeri** olarak veren `rapidc_sqlite3_open`
adında ince bir C sarmalayıcı sağlıyor; hata kodu ayrı bir
`rapidc_sqlite3_open_rc()` çağrısıyla okunuyor. rapidc tarafı bu ince
katmanı `extern fn` ile bildiriyor ve handle'ı boyunca opak bir `int`
olarak taşıyor (alanlarına hiç erişmiyor, sadece diğer sqlite3_* çağrılarına
geri veriyor).

Bu desen, gerçek dünyadaki dillerde de standarttır: bir C ABI'sinin
konuşma-diline (`rapidc`, Rust, Go, ...) doğrudan çevrilemeyen kısımları
(pointer'a pointer, struct by-value, union, variadic'in kendisi vb.) ince
bir C shim ile "düzleştirip" asıl dile öyle sunulur.

## Bilinen sınırlar

- **`sqlite3_exec` sonuç satırlarını okuyamıyor** — callback her zaman
  `0`/NULL geçiliyor, yani yalnızca `CREATE`/`INSERT`/`UPDATE`/`DELETE`
  gibi sonuç döndürmeyen komutlar için kullanılabilir. `SELECT` ile satır
  okumak `sqlite3_prepare_v2`/`sqlite3_step`/`sqlite3_column_*` API'sini
  gerektirir; bu ilk sürümde yok.
- `rapidc`, `shim "...";` direktifiyle bildirilen `.c` dosyalarını
  kendisi `cc -c` ile derler (M31) — ekstra include-path/define/
  optimizasyon bayrağı olmadan, dosyanın yanında `<dosya>.c.o` olarak.
  Shim'in derlenmesi için özel bir bayrağa (`-I`, `-D`, ...) ihtiyacı
  varsa bu henüz desteklenmiyor; böyle bir shim'i yine elle önceden
  derleyip `-obj <dosya.o>` ile son link adımına eklemeniz gerekir.
