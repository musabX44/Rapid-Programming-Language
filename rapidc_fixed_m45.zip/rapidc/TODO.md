# TODO — durum (güncellendi)

## Özet
Bu TODO'daki tüm maddeler tamamlandı. Aşağıda her madde için gerçek kök
neden ve yapılan düzeltme özetlenmiştir (bazıları ilk teşhisten farklı
çıktı — detaylar altta).

## 1) TAMAMLANDI — Blocker: `efn` parser bug

**Gerçek kök neden**, dosyadaki ilk teşhisten farklıydı: sorun `efn` +
`extern fn` kombinasyonuna özel değildi. `parser.y`'deki `efn` grammar
kuralı (`EFN IDENT LPAREN efn_param_list_opt RPAREN FATARROW expr`)
sondaki `;`'yi **hiç tüketmiyordu**. Bu yüzden `efn` içeren HERHANGİ bir
dosya (extern çağırsın çağırmasın, hatta hiçbir şey çağırmasa bile —
`efn wrap(a: int) => a;` tek başına bile) parse'ı bozuyordu: `yydebug`
ile izlendi, `;` bir üst seviyede stray token olarak kalıp
`function_list` reduce'unu bozuyordu.

**Düzeltme:** `EFN ... FATARROW expr` ve `PRIVATE EFN ... FATARROW expr`
kurallarının sonuna `SEMICOLON` eklendi (`parser.y`).

**Doğrulama:** efn-tek-başına, efn→normal fn, efn→efn, efn→extern fn,
main'den önce/sonra sıralama — hepsi derlendi. `m27tests`/`m28tests`/
`m29tests` içindeki tüm dosyalar (redecl-error ve rename-error negatif
testleri dahil) beklenen şekilde davranıyor.

## 2) TAMAMLANDI — `std/net.rapid` codegen bug'ı

Blocker düzelince ikinci, ayrı bir bug ortaya çıktı: void dönüşlü
`efn`-forwarding wrapper'ları (örn. `keyword`'ün rename dalının ürettiği
`http_free` wrapper'ı) geçersiz QBE IL üretiyordu: `ret (null)`.
Kök neden: `efn_new` her zaman `return <expr>;` şeklinde bir body
kuruyor (ast.c); expr'in tipi void olduğunda `gen_expr` NULL döndürüyor
(bu, void bir C-fonksiyon çağrısının "değeri" olmadığı için normal), ama
`STMT_RETURN` bu NULL'u `%s` ile doğrudan basıyordu → literal `"(null)"`
metni.

**Düzeltme:** `codegen.c`'de `STMT_RETURN`, `val == NULL` durumunda boş
`ret` basacak şekilde güncellendi.

**Doğrulama:** `net.rapid` artık parse+semantic+codegen+QBE aşamalarını
sorunsuz geçiyor. Kalan tek hata beklenen `-lcurl` linker hatası —
libcurl-dev bu sandbox'ta kurulamadı (network kısıtlı, TODO'da zaten
belirtilmişti). Kullanıcının kendi ortamında `apt install
libcurl4-openssl-dev` sonrası `net_shim.c` derlenip linklendiğinde
çalışması bekleniyor; gerçek HTTP GET isteği hâlâ doğrulanamadı (network
erişimi yok).

## 3) TAMAMLANDI (ve TODO'nun tahmininden daha geniş çıktı) — unary minus

**Gerçek kapsam**, "negatif ondalık literal" tanımından daha genişti:
`expr` grammar'ında unary minus (`-x`) HİÇ yoktu — yalnızca binary
`expr MINUS expr` kuralı vardı. Yani sadece `-5.5` değil, düz `-5` (int)
bile syntax error veriyordu.

**Düzeltme:**
- `parser.y`'ye `MINUS expr %prec UMINUS` kuralı eklendi.
- İlk denemem (`0 - expr` desugar) yanlış çıktı: `semantic.c`'nin
  `types_float_compatible()` fonksiyonu iki operandın da ÖNCEDEN float
  olmasını şart koşuyor, int `0` ile `double` karışımını kabul etmiyor —
  bu yüzden `-5.5` yine "type mismatch" veriyordu.
- Doğru çözüm: yeni bir `EXPR_NEG` AST düğümü (`ast.h`/`ast.c`),
  `semantic.c`'de operandın tipini aynen döndürüyor, `codegen.c`'de QBE'nin
  `neg` diye bir instruction'ı OLMADIĞI için `sub <sınıfa uygun sıfır>, x`
  şeklinde lowering yapılıyor (`sub 0, x` int için, `sub d_0, x` / `sub
  s_0, x` double/float için).

**Doğrulama:** `-5`, `-5.5`, `fabs(-5.5)`, `-x` (değişken), `-(-n)` (çifte
negatif), ve öncelik testleri (`-a * b`, `-a + b`) — hepsi doğru sonuç
verdi. Ayrı test dosyası: `m29tests/test_m29_negative_float_literal.rapid`
(keyword testleriyle karışmıyor).

## 4) TAMAMLANDI — küçük iyileştirmeler

- `README.md`'deki M29 bölümü güncellendi: artık kaldırılmış olan "isim
  eşleşmesi zorunlu" kısıtlaması metni silindi, yerine gerçek rename
  desteğinin nasıl çalıştığı (`__kw_ffi_<csembol>` gizli extern + `efn`
  forwarding wrapper) `module.c`'deki yorumla tutarlı şekilde anlatıldı.
- `m29tests/test_m29_keyword_in_string_literal.rapid` eklendi: bir string
  literal içinde geçen "keyword" kelimesinin yanlışlıkla top-level bir
  `keyword` bildirimi gibi genişletilmediğini doğruluyor (zaten güvenliydi,
  şimdi regresyona karşı test var).


## 5) TAMAMLANDI (M35) — fixed-size `int[]` core'dan kaldırıldı, `array::` kütüphanesi eklendi

Kullanıcı isteği üzerine: dilin sabit boyutlu dizi tipi (`TYPE_ARRAY`/
`TYPE_INT_ARRAY`, `int[]` sözdizimi, `[1,2,3]` literal-olarak-dizi-değeri,
`xs[i]` sabit dizi indekslemesi) derleyici çekirdeğinden (parser/semantic/
codegen) tamamen çıkarıldı. Bu, aynı zamanda BUG_REPORT.md'deki M33
eksikliğini kökten çözer: yeni sistemde uzunluk artık heap'te struct'ın
kendi alanı olarak taşınıyor, fonksiyona parametre olarak geçse bile
kaybolmuyor.

**Neyin korunduğu (bilinçli olarak dokunulmadı):**
- `EXPR_INDEX` (`xs[i]`) grammar kuralı: pointer indeksleme (`p[i]`),
  string indeksleme (`s[i]`), ve `list<int>`/`list<byte>` indekslemesi hâlâ
  aynı kod yolunu paylaşıyor ve hiç bozulmadı.
- `list<int>`/`list<byte>` (zaten var olan, ayrı, header-tabanlı dinamik
  liste sistemi) tamamen dokunulmadan bırakıldı — `push`/`len`/`for-in`
  hepsi eskisi gibi çalışıyor.
- `[e0,e1,...]` literal grameri de kaldırılmadı: artık sadece
  `list<int> xs = [1,2,3];` initializer'ı olarak geçerli.

**Yeni: `std/array.rapid`** — tamamen RapidC içinde (derleyiciye hiç
dokunmadan) yazılmış, struct tabanlı (`Array { data: int*; length: int;
capacity: int; }`), `alloc()`/pointer üzerine kurulu dinamik dizi
kütüphanesi. `array::` önekiyle kullanılıyor (`use "std/array.rapid" as
array;` + module.c'nin zaten var olan alias-mangling mekanizması —
grammar'a hiç dokunulmadı). API: `new`, `withCapacity`, `len`, `get`, `set`,
`push`, `pop`, `last`, `destroy`, `copy`, `fill`, `range`, `reverse`, `sum`,
`max`, `min`, `contains`, `indexOf`, `sort` (insertion sort), `print`.

**Doğrulama:** parser/semantic/codegen üç aşama da build edildi ve QBE IL
çıktısı elle incelendi (bu sandbox'ta `qbe` binary'sinin kendisi kurulamadı
— ağ kısıtlı — ama IL doğru ve QBE'nin kabul edeceği şekilde). Tüm
`m2*tests`/`m3*tests`/`examples` dosyaları (kütüphane-only dosyalar hariç,
onlar zaten `main` içermediği için tek başına asla derlenemez) parse+
semantic+codegen aşamalarını hatasız geçti — 0 regresyon. Etkilenen üç eski
dosya (`m33tests/test_m33_len_on_local_array_ok.rapid`,
`m33tests/test_m33_len_on_array_param_error.rapid`,
`examples/ptr_arith.rapid`) yeni `array::`/`alloc()` API'sine taşındı. Yeni
regresyon testleri: `m35tests/test_m35_arraylib_basic.rapid`,
`m35tests/test_m35_arraylib_sort_search.rapid`,
`m35tests/test_m35_fixed_array_removed_error.rapid` (eski `int[]`
sözdiziminin artık parse error verdiğini doğrular),
`m35tests/test_m35_ptr_index_still_works.rapid` (pointer indekslemenin
bozulmadığını doğrular).


## 6) TAMAMLANDI (M35) — `std/map.rapid`: hash map kutuphanesi

`array::` ile ayni felsefe: derleyiciye dokunmadan, tamamen RapidC icinde.
Iki tip: `Map` (string -> int) ve `IntMap` (int -> int). Acik adresleme +
dogrusal yoklama + tombstone; kapasite 2^k, doluluk %70'i gecince buyur/rehash.
String anahtarlar KOPYALANIR. Struct deger olarak gectigi icin degistiren
her fonksiyon sonucu geri atanir: `m = map::set(m, "a", 1);`.

API (Map): new, newCap, set, get, getOr, has, remove, clear, destroy, len,
inc, copy, merge, sum, forEach, print, cells, occupied, keyAt, valAt.
API (IntMap): ayni, `int` onekiyle (intNew, intSet, intGet, ...).

**Dogrulama:** 20000 rastgele islemlik stres testleri (Map ve IntMap,
negatif anahtarlar dahil) Python referansiyla birebir ayni; LD_PRELOAD
malloc izleyicisiyle kutuphane-only 100000 islemde 0 sizinti / 0 cift-free.

### Debug sirasinda bulunan derleyici hatalari (M36'da cozuldu)

1. **DUZELTILDI (M35) — `codegen.c`: `MAX_STRINGS 256` sinir kontrolsuzdu.**
   256'dan fazla FARKLI string literal rapidc'yi SIGSEGV ile dusuruyordu.
   Sinir 8192'ye cikarildi, tasmada temiz hata.
2. **DUZELTILDI (M36) — `string ==`/`!=` pointer kimligi karsilastiriyordu.**
   `"hello" == ("hel"+"lo")` false idi. Artik iki taraf da `string` ise
   `strcmp` (codegen.c). README'nin "tam uygulandi" notu simdi dogru.
3. **DUZELTILDI (M36) — struct-tipli PARAMETRENIN tipi cozulemiyordu.**
   `Param`'a `struct_name` eklendi (ast.h, parser.y'de 3 param kurali,
   semantic.c, codegen.c).
4. **DUZELTILDI (M36) — `var_struct_map` scope'suzdu.** Ayni ad iki farkli
   struct'a baglaninca SESSIZCE yanlis kod uretiliyordu (`1|2|3|4` yerine
   `2|2|3|4`). Harita artik fonksiyon-yerel (`var_struct_map_clear()`).
5. **DUZELTILDI (M36) — `module.c` alias mangling struct ALAN adini bozuyordu**
   (`fn count` varken `count: int;` alani `alias__count` oluyordu; yalniz
   `;` sonrasi gelen alanlar). `is_field_name_position` genisletildi.
   **KISMEN ACIK:** dosya kendi `len`/`free`'sini tanimlarsa ayni dosyadaki
   builtin `len(s)` cagrilari da mangle edilir (metin duzeyinde ayirt
   edilemez). Derleyici artik nedeni acik bir notla soyluyor.
6. **DUZELTILDI (M36) — `free(string)` desteklenmiyordu.** Artik kabul edilir;
   string LITERAL'i (statik veri) derleme zamaninda reddedilir.

### Debug sirasinda bulunan ek hatalar (M36)

7. **DUZELTILDI — `array::sort` bellek DISINA yaziyordu** (orijinal zip'te
   segfault). Zaten sirali dizide `j = -1000000000` yapip donguden sonra
   `a.data[j+1]`'e yaziyordu. `pos` degiskeniyle yeniden yazildi.
8. **DUZELTILDI — `MAX_FUNCS 64`** map(49)+array(27) birlikte kullanilinca
   asiliyordu. 512'ye cikarildi (semantic.c ve codegen.c'de AYNI olmali) ve
   codegen'e sinir kontrolu eklendi.
9. **DUZELTILDI — iki test yorumunda yanlis beklenen cikti:**
   `arraylib_basic` (64 -> 164), `arraylib_sort_search` (fazladan bir `5`).

### Hala acik / bilinen sinirlar
- (M37'de COZULDU) `null` artik `string`'e atanabilir ve `s == null` calisir.
- `list` rezerve keyword'dur; parametre/degisken adi olamaz.
- `parser.y`'de 1 shift/reduce cakismasi (M35 oncesinden var, sayi ayni).
- Sozlukte `len(s)` icin yukaridaki madde 5 notu.


## 7) TAMAMLANDI (M37) — `null` string + NULL-guvenli runtime + StrMap

Ayrintilar README.md "Milestone 37". Ozet: `null_fits_string()` yardimcisi
(semantic.c) 6 kullanim noktasina eklendi (bildirim, atama, alan atamasi,
argüman, return, `string*` eleman atamasi) + `s == null` icin BINOP kurali;
`runtime.c`'de strcmp/strcat/strlen/toInt/io::out NULL-guvenli; `std/map.rapid`'e
StrMap. Kalan: `s[i]` null'da hala korumasiz (hicbir string'te sinir kontrolu yok).
