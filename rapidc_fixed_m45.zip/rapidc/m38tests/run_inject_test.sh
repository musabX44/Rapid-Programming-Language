#!/bin/bash
# M38: komut enjeksiyonu regresyon testi. Kullanim: m38tests/run_inject_test.sh
# (repo kokunden, `make` sonrasi). Basarisizlikta 1 doner.
RAPIDC="$(cd "$(dirname "$0")/.." && pwd)/rapidc"
HERE="$(cd "$(dirname "$0")" && pwd)"
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
cd "$W" || exit 1
fail=0
check() { [ -e "$W/PWNED" ] || [ -e "$W/PWNED_BY_LINK" ] && { echo "FAIL: $1 (komut calisti)"; fail=1; rm -f "$W"/PWNED*; } || echo "ok:   $1"; }

"$RAPIDC" "$HERE/test_m38_inject_link_directive.rapid" -o out >/dev/null 2>&1
[ $? -ne 0 ] || { echo "FAIL: link yonergesi reddedilmedi"; fail=1; }
check "link \"...\" yonergesi"

echo 'fn main() { io::out(1); }' > ok.rapid
"$RAPIDC" ok.rapid -l 'm; touch PWNED #' -o out >/dev/null 2>&1
check "-l bayragi"

"$RAPIDC" ok.rapid -obj 'x.o; touch PWNED #' -o out >/dev/null 2>&1
check "-obj bayragi"

"$RAPIDC" ok.rapid -o 'o; touch PWNED $(touch PWNED) `touch PWNED`' >/dev/null 2>&1
check "-o yolu"
[ -x "$W/o; touch PWNED \$(touch PWNED) \`touch PWNED\`" ] && echo "ok:   -o adi birebir (literal) dosya adi olarak kullanildi" \
  || { echo "FAIL: metakarakterli -o adi literal kullanilmadi"; fail=1; }

# meşru kullanim bozulmamali
"$RAPIDC" ok.rapid -l m -l pthread -o good >/dev/null 2>&1 && [ "$(./good)" = "1" ] \
  && echo "ok:   mesru -l kullanimi" || { echo "FAIL: mesru -l kullanimi"; fail=1; }
exit $fail
