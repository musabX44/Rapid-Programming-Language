#!/bin/bash
# M41 regresyon testi. Kullanim: m41tests/run_m41.sh (repo kokunden, `make` sonrasi).
HERE="$(cd "$(dirname "$0")" && pwd)"
RAPIDC="$HERE/../rapidc"
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
fail=0
for src in "$HERE"/test_m41_*.rapid; do
  n=$(basename "$src" .rapid)
  if [[ "$n" == *_error ]]; then
    extra=""; [[ "$n" == *missing_use* ]] && extra="-nostd"
    out=$("$RAPIDC" "$src" $extra -o "$W/a" 2>&1); rc=$?
    if [ $rc -ne 0 ]; then echo "ok:   $n (beklenen derleme hatasi)"; else echo "FAIL: $n (hata beklenirdi)"; fail=1; fi
    continue
  fi
  "$RAPIDC" "$src" -o "$W/a" >"$W/log" 2>&1 || { echo "FAIL: $n (derlenmedi)"; cat "$W/log" | grep -v '^+' | head -5; fail=1; continue; }
  if "$W/a" | diff -q - "${src%.rapid}.expected" >/dev/null; then echo "ok:   $n"; else echo "FAIL: $n (cikti farkli)"; fail=1; fi
done
# std yolu: `use "std/std.rapid";` baska dizinden, rapidc'nin kendi dizinine dusmeli
mkdir -p "$W/proj"; printf 'use "std/std.rapid";\nfn main() { io::out(toInt("9") + len("ab")); }\n' > "$W/proj/p.rapid"
(cd "$W/proj" && "$RAPIDC" p.rapid -o p >/dev/null 2>&1 && [ "$(./p)" = "11" ]) \
  && echo "ok:   use \"std/std.rapid\" yedek yol (rapidc dizini)" || { echo "FAIL: std yedek yol"; fail=1; }
# -nostd: otomatik dahil etme kapaliyken use'suz kod hata vermeli ve ipucu basmali
"$RAPIDC" "$HERE/test_m41_std_missing_use_error.rapid" -nostd -o "$W/a" 2>&1 | grep -q 'use "std/std.rapid"' \
  && echo "ok:   -nostd + eksik use ipucu mesaji" || { echo "FAIL: -nostd ipucu yok"; fail=1; }
exit $fail
