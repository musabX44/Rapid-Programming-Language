
## M33: len() on fixed-size array function parameters (fixed as compile-time rejection)

**Found by:** Musab, while verifying `return`-in-loop early-exit behavior (which was already correct and needed no fix).

**Symptom:** `len(xs)` where `xs: int[]` is a function parameter silently returns `0` instead of the array's actual length.

**Root cause:** Fixed-size arrays are passed to functions as bare pointers with no length metadata. `codegen.c`'s `len()` handler reads the array's length from the local-variable table (`lt->array_len[idx]`), which is populated from the array literal initializer for locals (`var xs: int[] = [1,2,3];`) — but for parameters, `gen_function()` unconditionally calls `local_add(&lt, p->name, p->type, 0, ...)`, hardcoding length to 0. This isn't a bug in the sense of a lost value: the `Param` AST node (ast.h) has no length field at all, and the parser grammar rule for an `int[]` parameter type never captures a size, because none is ever passed at the call site. So no size is available anywhere in the compiler for this case — a real design gap, not a plumbing bug.

**Fix applied (M33):** Rather than a codegen patch (which had nothing to thread through), `semantic.c` now rejects `len()` on any bare-identifier argument that resolves to a `TYPE_INT_ARRAY` function parameter, with a clear error message suggesting the caller pass the length as a separate argument. `len()` on locals/globals initialized from an array literal is unaffected. This turns a silent wrong-answer bug into a compile-time diagnostic.

**Deliberately out of scope:** A real fix (fixed-size array types carrying their length, e.g. `int[5]`, or an implicit hidden length parameter at every call site) is a language/ABI design decision, not a bugfix, and is left for a future milestone.

**Verification:** `m33tests/test_m33_len_on_array_param_error.rapid` (expected to fail semantic check, confirmed) and `m33tests/test_m33_len_on_local_array_ok.rapid` (expected output `5`, confirmed via built qbe). Full m27/m28/m29 suites re-run with zero regressions.

## M38-A: Command injection via system() in main.c (CRITICAL, fixed)

**Symptom:** `link "m; touch /tmp/PWNED #";` in any `.rapid` file (or the same string via `-l`, `-obj`, `-o` on the command line) ran arbitrary shell commands on the machine compiling it.

**Root cause:** `run_cmd()` built one command string with `snprintf` and passed it to `system()` (`sh -c`), so link names, shim paths and the output path were interpreted as shell syntax.

**Fix applied (M38):** `main.c` no longer uses `system()`. Every external tool (`qbe`, `cc`, shim compilation) is run with `fork()` + `execvp()` on an explicit argv array, so each value is one inert argument. Defense in depth: library names (`link "x"` / `-l x`) must match `[A-Za-z0-9_.+:-]+` and are rejected otherwise; path arguments starting with `-` get a `./` prefix so they cannot be read as options; temp files are created with `mkstemps()` (unpredictable `/tmp/rapidc_XXXXXX.{ssa,s}`) instead of `/tmp/rapidc_<pid>.*`; the shim-compile failure path now removes its temp files (it leaked them before). The fixed-size flag buffers (silently truncating at `PATH_MAX`) are gone too.

**Not changed (by design):** `shim "x.c";` still compiles and links the named C file into the output binary. A hostile `.rapid` can therefore still ship hostile *code that runs when the built program runs*. Compiling untrusted `.rapid` is now safe; running what it produces is not.

**Verification:** `m38tests/run_inject_test.sh` (fails on the M37 compiler, passes now).

## M38-B: codegen LocalTable never shrinks: stack overflow + stale-name type confusion (fixed)

**Symptom:** more than 64 sequential `for (x in list)` loops in one function passed `semantic.c` but wrote past the `MAX_LOCALS` arrays of the stack-allocated `LocalTable` in `codegen.c` (UBSan: `codegen.c:74: index 64 out of bounds`). Separately, reusing a loop-variable name with a different type picked up the *old* entry: `for (x in bytes){} for (x in ints){ io::out(x); }` printed `A`/`B` instead of `65`/`66`.

**Root cause:** `STMT_FOR_IN` calls `local_add()` but never pops the entry at scope exit (`semantic.c` restores `st->count`; codegen had no equivalent), and `local_add()` had no bounds check. Only `for-in` and the function prologue (params + top-level decls) write to this table. The C-style `for (var ...)` form does not, so the original report's example does not overflow.

**Fix applied (M38):** `codegen.c` saves `lt->count` before registering the loop variable and restores it after the loop; `local_add()` now refuses to write past `MAX_LOCALS`, prints `too many local variables in one function`, and makes `codegen_emit()` return failure (main.c then cleans up temp files).

**Verification:** `m38tests/test_m38_forin_many_loops.rapid`, `m38tests/test_m38_forin_stale_type.rapid` (+ `.expected`; both fail on the M37 compiler). Differential run of all 70 `m*tests/`, `examples/`, `std/` files, old vs new compiler: identical compile results and program output.

## M39-A: `-o` output path not hardened like `-obj`/shim paths (fixed)

**Symptom:** `main.c`'s final `cc` invocation pushed `output_path` (the `-o`
value, from the command line) with plain `argv_push()`, while `-obj` and
shim `.o` paths already went through `argv_push_path()` (which prefixes a
leading `-` with `./` so it can't be read as an option by `cc`). A
dash-leading `-o` value (e.g. `rapidc x.rapid -o -v`) therefore reached
`cc -o <value>` unguarded — inconsistent with the hardening pattern applied
everywhere else, even though GNU `cc`'s own `-o` parsing happened to still
treat the next token as a filename in testing, so no concrete exploit was
found, only a guarantee gap.

**Fix applied (M39):** `argv_push(&cc, output_path)` -> `argv_push_path(&cc,
output_path)`. Verified: `-o -v` now reaches `cc` as `./-v`; legitimate `-o
myprog` unaffected; `m38tests/run_inject_test.sh`'s existing "-o yolu" case
still passes.

## M39-B: unbounded expression-nesting recursion crashes rapidc (CRITICAL, fixed)

**Symptom:** `check_expr()` (semantic.c) and `gen_expr()` (codegen.c) walk
the expression AST recursively with no depth limit. A `.rapid` file with a
few thousand levels of nested parenthesized expressions
(`((((1+1)+1)+1)...)`-- about 5000 levels at the default 8MB stack in this
sandbox) exhausts the C call stack and crashes `rapidc` itself with SIGSEGV
instead of a diagnostic. Confirmed via gdb backtrace: the crash is deep
inside repeated `gen_expr` self-calls (codegen.c:1409 at the time). Same
threat model as M38-A/B: reachable from any untrusted `.rapid` source file a
victim compiles.

**Root cause:** Neither function had any recursion-depth guard, unlike
`local_add()` (which already enforces `MAX_LOCALS`).

**Fix applied (M39):** Renamed both functions to `check_expr_inner`/
`gen_expr_inner` and added a thin wrapper under the original name
(`check_expr`/`gen_expr`) that increments/decrements a depth counter around
the call and, past `MAX_EXPR_DEPTH` (400), reports a clean error
(`sem_error("expression nested too deeply", NULL)` in semantic.c;
`g_codegen_error` + message in codegen.c, mirroring `local_add()`'s own
pattern) and returns instead of recursing further. No recursive call site
needed to change, since internal calls still go through the public name.

**Verification:** n=399 nesting levels compiles and runs correctly
(output `400`); n=400+ now fails cleanly with `semantic error: expression
nested too deeply` (exit 1) instead of segfaulting (previously exit 139 at
n=5000, confirmed deterministic). Full m27-m38 + examples regression suite
(67 files) re-run with zero new failures; `m38tests/run_inject_test.sh`
still fully passes.

## M44-A: FFI type safety -- shim signature cross-check (fixed)

**Symptom:** `extern fn` declarations had no check against the actual C
signature of the function they named. A mismatched declaration (wrong
arity, or `int` declared where the C side takes a pointer, or vice versa)
compiled silently and corrupted data or crashed only at runtime, with no
diagnostic pointing at the real cause.

**Fix applied (M44):** new `src/ffi_check.c`/`ffi_check.h`. For every
`extern fn` whose symbol is also *defined* (not just declared/used) in one
of the program's own `shim "x.c";` files, a lightweight textual scan of
the shim source extracts that C function's real parameter count and a
coarse per-parameter class (int-like / float-like / pointer-or-string-like,
decided by looking for a trailing `*` and a short table of known C base-
type keywords -- deliberately not a real C parser, no preprocessor or
typedef resolution beyond that table). `ffi_check_shim_signatures()` is
run from `main.c` right after `semantic_check()` and before codegen; any
arity or class mismatch is a hard compile-time error. `extern fn`
declarations with no matching shim definition (plain libc reached via
`link "...";`) are left unchecked, since there is nothing of ours to
compare them against.

**Verification:** `/tmp/ffi_bad.rapid` (extern `filename: int` against
the shim's actual `const char *filename`, plus a 2-vs-0 arity mismatch on
a second function) now fails with two specific diagnostics naming the
function, parameter index, declared class and expected class, before qbe
is ever invoked. `ffi/sqlite3.rapid`'s existing, correct `extern fn`
declarations against `ffi/sqlite3_shim.c` pass with no false positives,
confirmed end-to-end (qbe built from source, `-lsqlite3` resolved via a
`libsqlite3.so` dev-symlink since only the runtime `.so.0` is installed
in this sandbox): `rapidc_sqlite3_open("test.db")` returns a non-zero db
handle. Full `run_tests.sh` suite: 78 passed / 0 failed / 3 skipped,
unchanged.

**Found along the way, fixed in the same pass -- pre-existing, unrelated
to M44-A's own code:** `main.c` called `ast_reset()` (which
`memset()`s the whole of `g_program`, including `link_libs`/`link_objs`)
*after* `resolve_modules()` had already populated those two fields from
every `link "...";`/`shim "...";` directive in the source. Every such
directive was silently discarded before semantic_check or codegen ever
ran: `link "m";` never produced `-lm` on the final `cc` command, and no
`shim "x.c";` file was ever actually compiled/linked into the output
binary, despite `main.c`'s own link step appearing to handle both. This
went unnoticed because `ffi/sqlite3_shim.c` -- the only shim directive
anywhere in this repo -- is never exercised by `run_tests.sh`
(`examples/sqlite_demo.rapid` is one of its "harici bagimlilik" skips),
and nothing in the existing suite happens to combine `link "...";` with a
function that would fail to link without it (`std/`'s own libm calls are
reached through a `link "m";` in `std/std.rapid` which is *also* silently
dropped by this bug, but the resulting undefined-symbol link failure was
apparently never hit by the existing test programs' actual call graphs).
**Fix:** `main.c` now stashes `g_program.link_libs`/`link_objs` before
`ast_reset()` and splices them back onto the freshly-reset `g_program`
immediately after, since `yyparse()`'s own grammar rules for `link`/`shim`
are no-ops by design (module.c's pre-pass is the only thing that ever
populates these lists). Verified directly: `link "m"; extern fn
sqrt(x: double): double;` now produces `-lm` on the final `cc` invocation
and `sqrt(16.0)` runs and prints `4`; previously `-lm` was silently
absent from every build regardless of any `link "...";` directive present.
This is also what made ffi/sqlite3.rapid's end-to-end verification above
possible in the first place -- M44-A's own check would otherwise never
have seen a non-empty `link_objs` to cross-check against.

## M44-B: qbe-not-found error message (fixed)

**Symptom:** when the `qbe` binary was not on `PATH`, rapidc's only
diagnostic was the generic `rapidc: qbe backend failed`, identical to
what a *present* qbe prints after rejecting malformed IL (a real codegen
bug). A developer or CI box without qbe installed had no hint that
installing qbe, rather than debugging codegen, was the actual fix.

**Fix applied (M44):** `main.c` now checks `PATH` for an executable named
`qbe` itself (`command_exists_on_path()`, the same resolution `execvp()`
would do) immediately before invoking it. If absent:
`rapidc: qbe backend failed: binary not found` plus a short install
pointer (`https://c9x.me/compile/` / `github.com/8l/qbe`). If qbe *is* on
`PATH` and still exits non-zero, the original generic message is
unchanged, since that case is a real codegen/IL problem rather than a
missing-tool problem and the two must not be conflated.

**Verification:** with no `qbe` on `PATH`, `rapidc` now prints the
specific binary-not-found message and install pointer (confirmed: exit 1,
no `qbe` subprocess forked). With a fake `qbe` on `PATH` that always
exits 1, the original generic `qbe backend failed` message is printed
unchanged (confirmed both cases side by side). With a real qbe (built
from github.com/8l/qbe and installed for this verification pass), normal
builds proceed exactly as before; full `run_tests.sh`: 78 passed / 0
failed / 3 skipped.

## Re-examined: claimed `copy_until_balanced()` heap-buffer-overflow -- NOT reproduced

A prior audit report claimed a 4th real memory-safety bug: an unterminated
string literal inside a `keyword` declaration's parameter list
(`src/module.c:614`, `copy_until_balanced()`) allegedly makes the inner
string-scan loop stop at NUL while the outer loop's unconditional `p++`
still advances past it, reading one byte past the buffer.

**Re-investigation:** the function's actual code (both in this zip and as
built here) already has `if (!*p) continue;` at the end of the inner
string-scan branch, which routes back to the *outer* `while (*p)` loop
condition and explicitly skips the branch's own trailing `p++` when the
inner loop stopped on NUL -- i.e. the fix this report describes already
appears to be present in the source as shipped.

Tested three ways: (1) the function in isolation under ASan/UBSan with
the reported minimal trigger (`s: string, c: "unterminated`) against both
a plain and an exactly-sized `malloc`'d heap buffer (so a red zone sits
immediately past the data) -- no overflow, clean `NULL` return (correct
error path). (2) 400 randomized variants (varying parameter count,
escape-sequence runs near the end of the unterminated string, and which
of the four `keyword` sub-forms wraps it) against the same build -- 0
crashes, 0 overflows; every run hit only the project's existing,
unrelated lexer string-decode memory leak (harmless, process exits
immediately after). (3) the full project rebuilt with
`-fsanitize=address,undefined` and run end-to-end (`src/main.c`'s real
`yyparse`/`expand_keyword_decls` path, not just the isolated function) on
the exact minimal trigger text -- produces a normal `parse error: syntax
error` diagnostic, no ASan report.

**Conclusion:** this specific finding does not reproduce against the code
in this zip. Either it was already fixed before this snapshot, or the
original report's build differed in some way not captured here. Not
treated as an open issue; flagging in case a different code path (not the
minimal trigger above) was actually intended.
