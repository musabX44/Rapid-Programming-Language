# Rapid! Dil Referansı

Bu belge `rapidc` derleyicisinin desteklediği **Rapid!** dilinin baştan
sona, konuya göre organize edilmiş bir referansıdır (milestone kayıtları
için `README.md`, FFI detayları için `FFI-MANUAL.md`'ye bakın — orada aynı
bilginin çoğu, geliştirme sırasına göre dağınık şekilde bulunur; bu belge
onun yerine dile göre gruplanmış tek bir kaynak olmayı amaçlar).

Rapid!, statik tipli, derlenip native x86-64 Linux ELF ikili dosyası
üreten küçük bir sistem programlama dilidir:

```
.rapid → Flex (lexer) → Bison (parser) → AST → Semantic Check → QBE IL → qbe → as/ld (cc üzerinden) → ELF64
```

## İçindekiler

1. [Hızlı başlangıç](#1-hızlı-başlangıç)
2. [Sözdizimi temelleri](#2-sözdizimi-temelleri)
3. [Tipler](#3-tipler)
4. [Değişkenler ve sabitler](#4-değişkenler-ve-sabitler)
5. [Operatörler](#5-operatörler)
6. [Kontrol akışı](#6-kontrol-akışı)
7. [Fonksiyonlar](#7-fonksiyonlar)
8. [Diziler ve listeler](#8-diziler-ve-listeler)
9. [String'ler](#9-stringler)
10. [Struct'lar](#10-structlar)
11. [Enum'lar](#11-enumlar)
12. [İşaretçiler (pointer)](#12-işaretçiler-pointer)
13. [`io::` — girdi/çıktı](#13-io--girdiçıktı)
14. [Sistem programlama primitifleri](#14-sistem-programlama-primitifleri)
15. [Modüller (`use`)](#15-modüller-use)
16. [FFI — dış fonksiyonlar](#16-ffi--dış-fonksiyonlar)
17. [Hata mesajları](#17-hata-mesajları)
18. [Bilinen sınırlar](#18-bilinen-sınırlar)

---

## 1. Hızlı başlangıç

**Gereksinimler:** flex, bison, [qbe](https://c9x.me/compile/), cc/gcc, make.

```sh
apt-get install flex bison gcc make   # qbe kaynaktan derlenmeli, apt'ta yok
make
./rapidc program.rapid -o program
./program
```

En küçük geçerli program:

```
fn main() {
    io::out("Merhaba, Rapid!");
    return;
}
```

Her programda tam olarak bir `main` fonksiyonu olmalıdır (parametresiz,
`void`).

---

## 2. Sözdizimi temelleri

- Yorumlar: yalnızca tek satır, `// ...`.
- Her statement `;` ile biter (blok gövdeleri `{ }` hariç).
- Blok scoping: `if`/`while`/`for`/`do-while` gövdesinde deklare edilen
  `var`/`const` bloktan çıkınca görünmez.
- Tanımlar (fonksiyon, struct, enum) yalnızca **üst düzeyde** yapılabilir;
  iç içe fonksiyon/struct/enum yoktur.
- Tanımlayıcılar (`IDENT`): `[a-zA-Z_][a-zA-Z0-9_]*`.
- Anahtar kelimeler (rezerve, tanımlayıcı olarak kullanılamaz):
  ```
  extern link shim efn fn var const return void null true false
  int bool string byte char int8 int16 int32 int64
  uint8 uint16 uint32 uint64 float double
  struct enum list if else while do for in break continue
  switch case default use as private io
  ```
  Ayrıca derleyici tarafından reserve edilmiş (fonksiyon olarak yeniden
  tanımlanamaz) top-level isimler: `push`, `alloc`, `free`. (`len`, `listCopy`,
  `syscall`, `toInt`, `toString`, `toFloat`, `toDouble` M41'den itibaren
  `std/std.rapid` kütüphanesindedir; bkz. §19.)

---

## 3. Tipler

| Tip | Genişlik | Açıklama |
|---|---|---|
| `int` | 64-bit işaretli | varsayılan tamsayı tipi |
| `byte` | 8-bit işaretsiz | `char` bunun bir alias'ıdır |
| `int8`/`int16`/`int32`/`int64` | 8/16/32/64-bit işaretli | |
| `uint8`/`uint16`/`uint32`/`uint64` | 8/16/32/64-bit işaretsiz | |
| `float` | 32-bit IEEE-754 | |
| `double` | 64-bit IEEE-754 | ondalıklı literal (`3.14`) tek başına buna varsayılır |
| `bool` | — | `true` / `false` |
| `string` | — | heap'te ham `char*` |
| `void` | — | yalnızca fonksiyon dönüş tipi olarak |
| `T[]` (`int[]`, `byte[]`, `int16[]`, `int32[]`, `int64[]`, `float[]`, `double[]`, …) | — | sabit boyutlu (stack'te) dizi — `T` herhangi bir skaler tiptir |
| `list<int>` / `list<byte>` | — | heap'te büyüyebilen dinamik dizi |
| `T*` | — | işaretçi (herhangi bir `base_type`'a, `void*` hariç) |
| `T**` | — | işaretçiye işaretçi (yalnızca bu derinliğe kadar) |
| `fn(T1, T2, ...): Tret` | — | fonksiyon değeri (closure yok) |
| `struct AdıX` / `enum AdıX` | — | kullanıcı tanımlı |

**Örtük dönüştürme kuralları:**
- Tamsayı aileleri (`int`/`byte`/`int8..64`/`uint8..64`) birbirleriyle
  aritmetik/karşılaştırma/atama/çağrı bağlamlarında örtük uyumludur (C'nin
  "usual arithmetic conversions"ına yakın: daha geniş kazanır, eşit
  genişlikte işaretsiz kazanır).
- `float`/`double` birbiriyle örtük uyumludur (`float op double` her zaman
  `double`'a genişler).
- **Tamsayı ↔ float/double arasında örtük dönüşüm YOKTUR** — `int + float`
  semantic error verir. Açık `toFloat`/`toDouble` builtin'i henüz yok.

---

## 4. Değişkenler ve sabitler

```
var isim: tip = ifade;      // başlatılmış
var isim: tip;               // başlatılmasız (struct/dizi/pointer için de geçerli)
const AD: tip = ifade;       // sabit — atama/++/-- ile değiştirilemez
```

Tip çıkarımı yoktur; `:` sonrası tip her zaman açıkça yazılır (`efn` hariç,
bkz. §7).

---

## 5. Operatörler

**Aritmetik:** `+ - * / %` — `%` yalnızca tamsayı tipleri üzerinde
(`float`/`double` desteklenmez). `+` ayrıca `string` birleştirme için
overload edilmiştir.

**Kuvvet:** `^^` (C'deki `**` değil — `**pp` çift-dereference ile
çakışmasın diye kasıtlı olarak farklı sembol seçildi).

**Karşılaştırma:** `== != < <= > >=` — tamsayı, float/double, `bool`,
`string`, pointer üzerinde çalışır (relational `< <= > >=` pointer için de
geçerlidir). `string` karşılaştırması runtime'da `strcmp` ile yapılır
(sözlük sırası); `==`/`!=` doğrudan içerik eşitliği, `< <= > >=` `strcmp`
sonucunun işaretine göre.

**Mantıksal:** `&& || !` — yalnızca `bool` operand.

**Bit düzeyi:** `& | ^ << >>` — yalnızca tamsayı.

**Atama:** `=` ve bileşik atamalar `+= -= *= /= %= &= |= ^= <<= >>= ^^=`
(hepsi `x OP= e` → `x = x OP e` şeklinde desugar edilir; hedef `IDENT`,
`IDENT[expr]` veya `expr.IDENT` olabilir).

**Artırma/azaltma:** `++` / `--` — yalnızca postfix statement biçiminde
(`x++;`), yalnızca `int` ailesi üzerinde, `const` üzerinde yasak.

**Birli:** `-x` (negatif), `!x` (mantıksal değil), `&x` (adres al), `*x`
(dereference).

**Operatör önceliği** (düşükten yükseğe): `=` < `||` < `&&` < `|` < `^` <
`&` < `== != < <= > >=` (non-assoc) < `<< >>` < `+ -` < `* / %` <
birli `- !` < `^^` < indeksleme `[]` < alan erişimi `.`.

---

## 6. Kontrol akışı

### if / else if / else
```
if (cond) { ... }
else if (cond2) { ... }
else { ... }
```

### while
```
while (cond) { ... }
```

### do-while
```
do {
    ...
} while (cond);
```
Gövde **en az bir kez** çalışır, ardından `cond` `true` olduğu sürece
tekrarlanır. `continue`, gövdenin başına değil doğrudan koşul kontrolüne
atlar (koşul hiçbir zaman atlanmaz). `while (cond);` unutulursa parse
hatası verilir. Tek satırlık bir kısayolu yoktur.

### for (klasik üç parçalı)
```
for (var i: int = 0; i < N; i++) { ... }
```
- `init`: yalnızca `var isim: tip = ifade;` biçiminde bir bildirim olabilir
  (mevcut bir değişkene atama olamaz).
- `post`: yalnızca `isim = ifade`, `isim++` veya `isim--` olabilir.
- `init`'te bildirilen değişken, `for`'un tamamına (init+cond+post+body)
  özel scope'tadır.
- **`for`'un `while` gibi tek satırlık bir kısayolu yoktur** — üç parça da
  (init/cond/post) zorunludur, hiçbiri opsiyonel değildir.

### for-in (dizi/liste gezinme)
```
for (x in xs) { ... }
```
`xs` bir `T[]` (`byte[]`/`int32[]`/`float[]`/…), `list<int>` veya `list<byte>`
olmalı; `x`, elemanın tipine (döngü gövdesine özel scope'ta) bağlanır. İçeride
`while` + gizli
indeks sayacına desugar edilir.

### break / continue
En içteki döngüyü hedefler (`while`/`do-while`/`for`/`for-in`); döngü
dışında kullanımı semantic error'dur.

### switch
```
switch (expr) {
    case v1: ...
    case v2: ...
        break;
    default: ...
}
```
C tarzı fall-through (bir `case`'in sonuna `break` konmazsa bir sonrakine
düşer); en fazla bir `default` olabilir; `case` değer tipi `switch`
subject'iyle eşleşmelidir.

---

## 7. Fonksiyonlar

### Normal fonksiyon
```
fn ad(param1: tip1, param2: tip2): dönüş_tipi {
    ...
    return ifade;
}
```
Dönüş tipi yazılmazsa (`fn ad(params) { ... }`) `void` varsayılır.
`return;` (değersiz) yalnızca `void` fonksiyonda, `return ifade;`
(değerli) yalnızca `void`-olmayan fonksiyonda geçerlidir.

Fonksiyonlar dosyada herhangi bir sırada tanımlanabilir; ileri referans ve
doğrudan/dolaylı recursion serbestçe çalışır (semantic check iki geçişli:
önce tüm imzalar toplanır, sonra gövdeler kontrol edilir).

### efn — tek ifadeli kısayol
```
efn square(x) => x * x;
efn greet(name: string) => "Hello " + name;
```
`efn AD(PARAMS) => IFADE;` parser seviyesinde gövdesi tek bir
`return IFADE;` olan normal bir `fn`'e desugar edilir. Parametreler
tipsiz yazılabilir (varsayılan `int`) ya da açıkça tiplenebilir, aynı
`efn` içinde karışık kullanılabilir. Dönüş tipi ifadenin tipinden
**çıkarılır**. Normal fonksiyonlarla tamamen aynı kurallara tabidir
(yeniden tanımlama/reserved-isim/tip kontrolü).

### private
```
private fn yardimci(...) { ... }
```
Tanımı yalnızca kendi dosyasına kapatır (bkz. §15).

### Fonksiyon değerleri (first-class, closure YOK)
```
var op: fn(int): int = square;
io::out(op(5));
op = double;

fn apply(f: fn(int): int, x: int): int { return f(x); }
```
Bare bir fonksiyon adı (parantezsiz) otomatik olarak `fn(...)` tipinde bir
değer sayılır. `fn(...)` düz bir tip tag'idir — tutulan gerçek fonksiyonun
tam imzası çağrı sitesinde satır satır doğrulanmaz. Reserved builtin'ler
(`push`/`len`/...) ve `extern fn` fonksiyon değeri olarak alınamaz.

---

## 8. Diziler ve listeler

### Sabit boyutlu dizi (`T[]`)
`int[]` sınırlı kalmıyor: artık `byte[]`, `int16[]`, `int32[]`, `int64[]`,
`float[]`, `double[]` ve işaretli/aksiz eşdeğer tiplerinden **herhangi biri**
`T[]` biçiminde tanımlanabilir. `T`, desteklenen skaler tiplerden herhangi biri
olanan bir temel türdür (struct/enum dizi desteklenmez).

```
var xs: int[]      = [1, 2, 3];
var bs: byte[]     = [10, 20, 30];
var i32: int32[]   = [1000, 2000];
var dbl: float[]   = [1.5, 2.5, 3.5];

xs[0];          // okuma
xs[0] = 10;     // yazma (değer, dizinin elem tipine uyumlu olmalı)
len(xs);        // 3 — compile-time'da hesaplanır
for (v in xs) { io::out(v); }
```

Dizi literalindeki öğeler, beyaz/uzunluk farkını tolere eder ama **sayısal
famililer karıştırılamaz**: `[1, 2.5]` geçersizdir (int+float karışık array
reddedilir). Stack'te ayrılır. Literalin eleman genişliği (`byte` ise 1,
`int32` ise 4 …) saklanır; kod üretimi `storeb`/`storeh`/`storew`/`stores`/
`stored`/`storel` seçer.

`len()` ve `for (v in xs)` bir **yerel** `T[]` üzerinde çalışır. **`len()`,
bir fonksiyon parametresi olarak geçirilen `T[]` üzerinde çalışmaz** — pointer
olarak geçtiği için boyutu çağrı sitesinde bilinmez; bu derleme zamanında açıkça
reddedilir (bkz. §18). Aynı sınır `byte[]`/`int32[]` … tüm çeşitlerde geçerlidir.

### Dinamik liste (`list<int>`, `list<byte>`)
```
var xs: list<int> = [1, 2, 3];   // veya [] (boş)
push(xs, 4);        // sona ekler, gerekirse kapasiteyi 2 katına çıkarır
var ys: list<int> = listCopy(xs); // bağımsız derin kopya
len(xs);             // eleman sayısı (runtime'da)
```
Heap'te `[len:8][cap:8][data...]` header'ıyla tutulur. `push`, gerekirse
`xs`'i otomatik olarak yeni pointer'a günceller. `push`/`listCopy`/`len`
derleyici tarafından reserve edilmiştir.

`xs[i]` okuma/yazma ve `for (x in xs)` hem `int[]` hem `list<int>`/
`list<byte>` üzerinde çalışır.

---

## 9. String'ler

```
var s: string = "merhaba\ndunya";   // \n \t \" \\ escape'leri desteklenir
var t: string = s + "!";            // birleştirme (rapidc_strcat)
s == t;  s != t;  s < t;            // strcmp tabanlı karşılaştırma
s[i];                                 // byte okuma (yazma yok)
len(s);                               // strlen
toInt(s);      // string -> int
toString(42);  // int/byte -> string
```

---

## 10. Struct'lar

```
struct Point {
    x: int;
    y: int;
}

fn main() {
    var p: Point = Point { x: 1, y: 2 };
    io::out(p.x);
    p.x = 5;
}
```
Alanlar `;` veya `,` ile ayrılır — **her alandan sonra** (son alan dahil)
bir ayraç gerekir; sondaki ayracı atlamak parse hatası verir. Struct
literal alan sırası bildirim sırasıyla aynı olmak zorunda değildir.
`private struct` ile dosyaya kapatılabilir. Alan erişimi zincirlenebilir
(`o.inner.a`), iç içe struct alanları desteklenir.

---

## 11. Enum'lar

```
enum Color {
    Red,
    Green,
    Blue = 10
}

var c: Color = Color::Blue;
```
Üye değeri verilmezse önceki üyeden +1 (ilk üye 0'dan başlar). `private
enum` ile dosyaya kapatılabilir.

---

## 12. İşaretçiler (pointer)

```
var x: int = 42;
var p: int* = &x;      // adres al
var pp: int** = &p;    // pointere pointer

*p;          // dereference (okuma)
*p = 100;    // dereference (yazma)
**pp;        // çift dereference
```
`T*` herhangi bir `base_type`'a uygulanabilir (`void*` hariç — reddedilir).
`T**` desteklenir ama `T***` (üç seviye) grammar hatası verir. İki pointer
`==`/`!=`/`< <= > >=`/`-` (fark) ile karşılaştırılabilir; pointee tipleri
farklıysa (biri `null` değilse) semantic error. `null`, herhangi bir `T*`
ile karşılaştırılabilir (kendi sabit pointee tipi yoktur).

`&`, yalnızca "adreslenebilir" bir lvalue'ya (int/byte gibi
`type_ptr_ok()` tipinde bir değişkene) uygulanabilir — `float`/`double`
lvalue'ların adresi alınamaz.

### 12.1 Pointer aritmetiği (C semantiği)

`T*` ile `int` arasında `+`, `-` (ve ters sıralama `int + T*`) desteklenir;
`T* - T*` iki pointerun arasındaki **eleman** sayısını verir (byte farkı değil).
İşletme, pointerin gösterdiği tipe göre ölçeklenir — yani `p + 1`, `p`'nin
gösterdiği türün byte cinsinden boyutu kadar ileri gider (`int*` için 8,
`byte*` için 1). `p++`/`p--` da aynı ölçeklendirme kurallarıyla çalışır.

```
var a: int[] = [10, 20, 30, 40, 50];
var p: int* = &a[0];
io::out(*(p + 1));   // 20  — ölçeklendirilmiş: a[1]
io::out(*(2 + p));   // 30  — int + T* da geçer
var q: int* = p + 3;
io::out(q - p);      // 3   — eleman farkı
p++;
io::out(*p);         // 20
```

Ayrıca `T*` üzerinde doğrudan `p[i]` okuma/yazma da desteklenir (C'deki
`p[i]` == `*(p+i)` eşdeğeri), ölçeklendirme aynı kuralla yapılır:

```
io::out(p[1]);        // a[1] == 20
p[2] = 300;           // a[2]'yi yazar (p a[0]'da iken)
io::out(a[2]);        // 300
```

Yalnızca `+` ve `-` kullanılabilir; `int - T*` (ters yönlü çıkarma) ve
işaretçilerle `*`/`/`/`%` gibi diğer aritmetikler semantic hatasıdır — bu,
C'nin aynı kısıtlamalarını yansıtır.

---

## 13. `io::` — girdi/çıktı

```
io::out(x);                        // tek değer + newline
io::out("Merhaba, {}! Yas: {}", name, 25);  // {} yer tutuculu format
var line: string = io::in();       // stdin'den bir satır oku (trailing \n atılır)
```
Çok argümanlı `io::out(fmt, ...)`, `fmt` içindeki her `{}`'yi sırasıyla
argümanlarla değiştirir (int/byte/string karışık olabilir; **float/double
desteklenmez** bu formda — yalnızca tek argümanlı `io::out(f)` float
basar, `%g` formatıyla).

**Dosya G/Ç (ham syscall wrapper'ları):**
```
io::open(path: string, flags: int, mode: int): int   // fd döner, hata: negatif
io::read(fd: int, buf: byte*|int*|string, count: int): int
io::write(fd: int, buf: byte*|int*|string, count: int): int
io::close(fd: int): int
io::errno(): int   // son io:: çağrısının errno'su (yalnızca başarısızlıkta anlamlı)
```
Yaygın flag değerleri (dilde henüz sabit yok, ham int girilir):
`O_RDONLY=0 O_WRONLY=1 O_RDWR=2 O_CREAT=64 O_TRUNC=512 O_APPEND=1024`
(bit-or ile birleştirilir, örn. `O_WRONLY|O_CREAT|O_TRUNC = 577`).

---

## 14. Sistem programlama primitifleri

```
var p: int* = alloc(64);   // malloc benzeri, byte cinsinden boyut
*p = 42;
free(p);

var pid: int = syscall(39, 0, 0, 0, 0, 0, 0);  // ham Linux syscall (SYS_getpid)
```
`syscall`, 1 (yalnızca numara) ile 7 (numara + 6 argüman) arasında int
argüman alır. `alloc`/`free`/`syscall` reserve isimlerdir.

---

## 15. Modüller (`use`)

```
use "dosya.rapid";              // içe aktar (kaynak-seviyesi önişlemci)
use "dosya.rapid" as takma_ad;  // alias altında içe aktar
```
`use`, `main.c` içinde `yyparse()` çağrılmadan önce çalışan bir metin
birleştirme adımıdır — lexer/parser bunun tek dosya olduğunu bilmez.
Aynı dosya birden fazla yerden `use` edilirse yalnızca bir kez dahil
edilir (diamond import); döngüsel `use` derleme zamanında reddedilir.

Alias'lı içe aktarımda, o dosyanın public üst-seviye isimleri yalnızca
`takma_ad::isim` ile erişilebilir:
```
use "vecmath.rapid" as vm;
io::out(vm::add(3, 4));
```

`private fn`/`efn`/`struct`/`enum`, tanımı yalnızca kendi dosyasına
kapatır — `use` eden başka bir dosya (alias ile bile) erişemez. Bir
modülün kendi `main`'i, entry-point dosyası dışında her zaman örtük
private kabul edilir (iki dosyanın `main` çakışması olmaz).

`use` yolları kullanan dosyaya göre relative'dir (mutlak yol da kabul
edilir).

---

## 16. FFI — dış fonksiyonlar

Ayrıntılar için `FFI-MANUAL.md`; kısa özet:

### extern fn — C fonksiyonu bildirimi
```
extern fn strlen(s: string): int;
extern fn printf(fmt: string, ...): int;   // varargs: sondaki `, ...`
extern fn exit(code: int): void;
```
Gövdesiz, `;` ile biter, dönüş tipi her zaman açık yazılmalıdır. Yalnızca
doğrudan isimle çağrılabilir (fonksiyon değeri olarak alınamaz).

### link — harici kütüphane linkleme
```
link "m";          // -lm
extern fn sqrt(x: double): double;
```
Son `cc` link komutuna `-l<isim>` ekler.

### shim — otomatik C shim derleme
```
shim "sqlite3_shim.c";   // rapidc kendisi `cc -c` ile derleyip linke ekler
```
`use` ile aynı relative-yol çözümlemesini kullanır; ayrı bir `cc -c`
adımına gerek kalmaz.

**Güvenlik:** bir `shim "...";` direktifi (doğrudan dosyanızda ya da `use`
ile dahil ettiğiniz herhangi bir dosyada — `std/net.rapid`/`ffi/sqlite3.rapid`
dahil) rapidc'nin, o C dosyasını derleyip çıktı ikilinize **gömmesine**
yol açar. Güvenmediğiniz bir `.rapid` dosyasını derlemek, onun işaret
ettiği keyfi C kodunu da derleyip çalıştırılabilir hale getirmemeli —
bu yüzden rapidc varsayılan olarak bir shim gördüğünde derlemeyi durdurur
ve açık `-allow-shim` bayrağı ister:
```
rapidc program.rapid -o program -allow-shim
```
`std/net.rapid` veya `ffi/sqlite3.rapid` kullanan programlar bu bayrak
olmadan derlenmez; bu, "üçüncü taraf `.rapid` dosyasını hiç şüphelenmeden
derleme" senaryosunun güvenli varsayılan olması içindir.

### keyword — yeniden adlandırılabilir FFI kısayolu
```
keyword sqrt(x: double): double  => extern "sqrt" from "m";
keyword httpGet(url: string, out_status: int*): string
    => extern "rapidc_http_get";
```
`keyword AD(...) => extern "csembol" [from "kütüphane"];`, derleyici
koduna dokunmadan, saf metinsel bir genişletme adımında (`module.c`)
`link` + `extern fn` (+ isim farklıysa bir `efn` forwarding wrapper'ı)
çiftine dönüştürülür. `use` edilen bir dosya içinde tanımlanabilir —
yani bir "FFI keyword kütüphanesi" ayrı `.rapid` dosyasında toplanıp
projeler arasında paylaşılabilir. Standart kütüphane bunun üstüne
kuruludur: `std/math.rapid` (libm, 28 fonksiyon), `std/net.rapid`
(libcurl üzerinden basit HTTP GET).

---

## 17. Hata mesajları

`rapidc`, kaynağı iki aşamada denetler:

**Syntax hataları (parser):** `dosya:N: parse error: mesaj` biçiminde,
dosya yolu ve satır numarasıyla basılır (M42; `use` ile içe alınan
dosyalarda da o dosyanın kendi satırı). Parser bir syntax hatasında tamamen durmaz —
bozuk statement/tanımı bir sonraki `;` veya `}`'a kadar atlayıp
dosyanın geri kalanını parse etmeye devam eder, böylece tek çalıştırmada
birden fazla syntax hatası birden raporlanabilir. Herhangi bir syntax
hatası varsa derleme yine de `parse failed` ile başarısız sonuçlanır.

**Semantic hataları (M42):** `dosya:N: semantic error: mesaj: isim` biçiminde
basılır. Konum, hatanın bulunduğu en içteki ifade/statement'ın satırıdır;
birkaç satıra yayılan ifadelerde son tokenin satırı gösterilebilir. Konumu
olmayan nadir hatalar (ör. `no main function found`) eski biçimde
(`semantic error: mesaj: isim`) basılır.
Semantic check de ilk hatada durmaz, bulduğu tüm hataları biriktirip
hepsini raporladıktan sonra `semantic check failed` ile başarısız olur.

---

## 19. Standart çekirdek kütüphane: `std/std.rapid` ve overload (M41)

```
// len, listCopy, toInt, toString, toFloat, toDouble, syscall: use satırı GEREKMEZ,
// std/std.rapid her programa otomatik dahil edilir (kapatmak için: rapidc ... -nostd)
io::out(toInt("42") + len("abc"));   // öneksiz (legacy yazım)
io::out(std::toString(7));           // önek opsiyonel
```
Kütüphane `module std global;` ile yazılmıştır: isimleri mangle edilmez, `std::`
öneki silinir. Açık `use "std/std.rapid" as s;` ek bir önek olarak (`s::toInt`) çalışır.
Açık `use` yolu göreli bulunamazsa `rapidc`'nin dizininde aranır.

**Overload:** ayni adda, parametre tipleri farklı birden fazla `fn`/`efn` tanımlanabilir:
```
fn show(x: int): string    { return "int"; }
fn show(x: string): string { return "str"; }
```
Seçim argüman tiplerine göre yapılır (tam eşleşme, tamsayı/float uyumundan önce gelir;
eşitlikte ilk tanım). Aynı imza `redeclaration` hatasıdır; `extern fn` overload edilemez.
Overload'lu bir ismin bare adı (`var f: fn(int): int = show;`) ilk tanıma bağlanır.

Derleyicide kalan icsel fonksiyonlar: `push`, `alloc`, `free`, `toInt(enum)`.

---

## 18. Bilinen sınırlar

- `len()`, bir fonksiyon parametresi olarak geçirilen `int[]` üzerinde
  çalışmaz (derleme zamanında reddedilir) — boyut bilgisi ham pointer'la
  taşınmaz; boyutu ayrı bir `int` parametre olarak geçirin.
- `T***` (üç seviye pointer) desteklenmiyor, yalnızca `T*`/`T**`.
- `void*` reddedilir.
- `float`/`double` için: pointer yok, `++`/`--` yok, array/list eleman
  tipi olarak henüz yok, çok argümanlı `io::out(fmt, ...)` içinde
  desteklenmiyor, tamsayı tiplerine örtük dönüştürülmüyor.
- `int8..64`/`uint8..64` için işaretçi (`int32*` gibi) yok — yalnızca
  `int*`/`byte*`.
- Fonksiyon değerleri (`fn(...)`) closure yakalamaz, tam imza kontrolü
  yapılmaz, `extern fn` fonksiyon değeri olarak alınamaz.
- `array`/`struct`'ı by-value bir `extern fn`'e geçirmek/döndürmek C ABI
  uyumu garanti edilmeden test edilmemiştir.
- Semantic hata mesajlarında satır numarası yoktur (yalnızca syntax
  hatalarında var).


---

## 20. Hata yönetimi (M43)

Hata yönetimi, Zig'deki "error union" modelinin sade bir uyarlamasıdır: istisna
(exception) yoktur, gizli kontrol akışı yoktur ve bir hatayı **yok saymak
derleme hatasıdır**.

### Söz dizimi

```
fn parse(s: string): !int {          // `!T`: int döner VEYA hata verir
    if (len(s) == 0) { fail error::Empty; }
    return toInt(s);
}

fn twice(s: string): !int {
    var v: int = try parse(s);       // hata varsa AYNI hatayla buradan da çık
    return v * 2;
}

fn main() {
    io::out(twice("21") catch 0);    // hata varsa varsayılan değer: 42
    io::out(twice("") catch -1);     // -1
    io::out(errname(lasterr()));     // "Empty"
}
```

| Yapı | Anlamı |
|---|---|
| `: !T` | Fonksiyon `T` döndürebilir ya da hata verebilir (`!void` de olur). |
| `fail error::Ad;` | Bu fonksiyondan `Ad` hatasıyla çık. Yalnızca `: !T` fonksiyonda geçerli. |
| `try çağrı` | Hata varsa aynı hatayla geri dön; yoksa değeri ver. Yalnızca `: !T` fonksiyonda. |
| `çağrı catch varsayılan` | Hata varsa hatayı "yakala" ve `varsayılan`ı kullan (yalnızca hata olursa değerlendirilir). `!void` çağrıda varsayılan yalnızca yan etki içindir (`f() catch io::out("hata");`). |
| `error::Ad` | Hata değeri (bir `int` kodu, ≥ 1). İlk kullanımda otomatik tanımlanır. |
| `lasterr()` | En son `catch` ile yakalanan hatanın kodu (`std`'den; hiç yakalanmadıysa 0). |
| `errname(kod)` | Hata kodunun adı (`error::Empty` → `"Empty"`). |

`catch` en düşük öncelikli ikili işleçtir (`a() catch b + c` = `a() catch (b + c)`).
`try` tekli işleç gibi sıkı bağlanır (`try a() + try b()` = `(try a()) + (try b())`).

### Derleyicinin zorladığı kurallar

- Hata dönebilen bir çağrı **yalnızca** `try` veya `catch` ile kullanılabilir.
  `var x: int = parse(s);` ve tek başına `parse(s);` semantic hatadır.
- `try` ve `fail`, yalnızca kendisi `: !T` olan fonksiyonda geçerlidir.
  `main` `!T` olamaz: hataları `catch` ile bitirmelisin.
- `try`/`catch` yalnızca hata dönebilen bir **çağrıya** uygulanır.
- `catch` varsayılanının tipi çağrı sonucuyla uyumlu olmalıdır (`double` sonuç için `1` değil `1.0`).
- Hata dönebilen fonksiyon fonksiyon değeri olarak alınamaz (`var f: fn(): int = p;` hatadır).
- `: !T` ile struct değer dönülemez (şimdilik); `extern fn` hata dönemez.

### Nasıl çalışır

Hata dönen fonksiyon, hata anında global `rapid_err` değişkenine sıfırdan farklı
kodu yazıp boş değer döndürür. `try` çağrıdan sonra bu değişkene bakar ve doluysa
fonksiyondan çıkar; `catch` kodu `rapid_last`'a taşıyıp temizler. Derleyici,
hata dönebilen çağrıların `try`/`catch` dışında kullanılmasına izin vermediği için
normal kodda `rapid_err` her zaman 0'dır. Maliyet: hata dönebilen her çağrıdan sonra
bir bellek okuması ve bir dallanma; ek tahsis yok, `unwinding` yok, çalışma zamanında
tür bilgisi yok.

### Sınırlar (bilinçli veya henüz yapılmadı)

- Hatanın bir **yükü (payload)** yoktur, yalnızca kodu ve adı vardır; `catch |e|` ile
  bağlama yok, bunun için `lasterr()` kullanılır (en son yakalananı verir).
- Hata adları bildirilmez: `error::Ad` ilk kullanımda tanımlanır ve tüm modüllerde
  **tek ortak ad uzayındadır**. Yazım hatası (`error::NotFond`) sessizce yeni bir hata olur.
- Global durum kullanıldığı için çok iş parçacıklı (thread) kullanımda güvenli değildir
  (dilde thread yok). `defer`/temizlik mekanizması yok.
