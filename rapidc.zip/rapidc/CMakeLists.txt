cmake_minimum_required(VERSION 3.16)
project(rapidc C)

set(CMAKE_C_STANDARD 11)

# --- flex & bison ---
find_package(FLEX REQUIRED)
find_package(BISON REQUIRED)

FLEX_TARGET(lexer src/lexer.l ${CMAKE_CURRENT_BINARY_DIR}/lexer.yy.c)
BISON_TARGET(parser src/parser.y ${CMAKE_CURRENT_BINARY_DIR}/parser.tab.c
             DEFINES_FILE ${CMAKE_CURRENT_BINARY_DIR}/parser.tab.h)
ADD_FLEX_BISON_DEPENDENCY(lexer parser)

# --- sources ---
set(OWN_SOURCES
    src/main.c
    src/ast.c
    src/semantic.c
    src/codegen.c
    src/var_struct_map.c
    src/module.c
    src/ffi_check.c
)

add_executable(rapidc
    ${OWN_SOURCES}
    ${FLEX_lexer_OUTPUTS}
    ${BISON_parser_OUTPUTS}
)

target_include_directories(rapidc PRIVATE src ${CMAKE_CURRENT_BINARY_DIR})

# Warnings: strict on our code, lenient on generated files
if(MSVC)
    target_compile_options(rapidc PRIVATE /W3)
else()
    # Own sources get -Werror; generated files do not (flex/bison warnings)
    set_source_files_properties(${OWN_SOURCES} PROPERTIES
        COMPILE_OPTIONS "-Wall;-Wextra;-Werror")
endif()

# --- runtime.o (linked into every compiled program, not into rapidc itself) ---
add_library(rapidc_runtime OBJECT src/runtime.c)
target_include_directories(rapidc_runtime PRIVATE src)
if(NOT MSVC)
    target_compile_options(rapidc_runtime PRIVATE
        -Wall -Wextra -Werror
        -ffunction-sections -fdata-sections)
endif()
target_link_libraries(rapidc_runtime PRIVATE m)

# Copy runtime.o next to the rapidc binary after build
add_custom_command(TARGET rapidc POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy
        $<TARGET_OBJECTS:rapidc_runtime>
        $<TARGET_FILE_DIR:rapidc>/runtime.o
    COMMENT "Copying runtime.o next to rapidc"
)

# libm
if(NOT WIN32)
    target_link_libraries(rapidc PRIVATE m)
endif()

# Install
install(TARGETS rapidc DESTINATION bin)
install(FILES $<TARGET_FILE_DIR:rapidc>/runtime.o DESTINATION bin)
